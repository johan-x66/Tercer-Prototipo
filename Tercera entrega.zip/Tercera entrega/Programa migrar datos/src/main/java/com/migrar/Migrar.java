package com.migrar;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import com.migrar.Data.DatabaseConectionNoRelacional;
import com.migrar.Data.DatabaseConectionRelacional;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.bson.types.ObjectId;

public class Migrar {

    private static Connection conn = null;

    public static boolean migrarTodo() {

        long inicioGlobal = System.currentTimeMillis();
        int totalProcesado = 0;
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("HH:mm:ss");
        String horaInicio = LocalTime.now().format(fmt);

        MongoDatabase db = DatabaseConectionNoRelacional.getDatabase();

        // Solo 3 colecciones según el diagrama NO relacional
        MongoCollection<Document> coleccionFarmacias    = db.getCollection("Farmacias");
        MongoCollection<Document> coleccionMedicamentos = db.getCollection("Medicamentos");
        MongoCollection<Document> coleccionProveedores  = db.getCollection("Proveedores");

        try {
            conn = DatabaseConectionRelacional.getConnection();

            if (conn == null) {
                System.out.println("Error: no se pudo conectar a la base de datos relacional.");
                return false;
            }

            // =====================================================
            // 1. MIGRAR PROVEEDORES (colección independiente)
            // =====================================================
            System.out.println("Migrando proveedores...");
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(
                         "SELECT ID, RAZON_SOCIAL, REPRESENTANTE_LEGAL, DIRECCION, TELEFONO, ESTADO FROM PROVEEDOR")) {

                while (rs.next()) {
                    Document doc = new Document("_id", new ObjectId())
                            .append("id",                rs.getInt("ID"))
                            .append("razonSocial",        rs.getString("RAZON_SOCIAL"))
                            .append("representanteLegal", rs.getString("REPRESENTANTE_LEGAL"))
                            .append("direccion",          rs.getString("DIRECCION"))
                            .append("telefono",           rs.getString("TELEFONO"))
                            .append("estado",             rs.getString("ESTADO"));

                    coleccionProveedores.insertOne(doc);
                    totalProcesado++;
                }
            }
            System.out.println("Proveedores migrados correctamente.");

            // =====================================================
            // 2. MIGRAR MEDICAMENTOS (colección independiente)
            // =====================================================
            System.out.println("Migrando medicamentos...");
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(
                         "SELECT ID, NOMBRE, GRAMAJE, PRECIO, NITFARMACIA, IDPROVEEDOR FROM MEDICAMENTO")) {

                while (rs.next()) {
                    Document doc = new Document("_id", new ObjectId())
                            .append("id",          rs.getInt("ID"))
                            .append("nombre",      rs.getString("NOMBRE"))
                            .append("gramaje",     rs.getDouble("GRAMAJE"))
                            .append("precio",      rs.getDouble("PRECIO"))
                            .append("nitFarmacia", rs.getInt("NITFARMACIA"))
                            .append("idProveedor", rs.getInt("IDPROVEEDOR"));

                    coleccionMedicamentos.insertOne(doc);
                    totalProcesado++;
                }
            }
            System.out.println("Medicamentos migrados correctamente.");

            // =====================================================
            // 3. MIGRAR FARMACIAS con VENTAS EMBEBIDAS
            //    Cada farmacia lleva un array "ventas" dentro
            // =====================================================
            System.out.println("Migrando farmacias con ventas embebidas...");

            try (Statement stmtFarmacia = conn.createStatement();
                 ResultSet rsFarmacia = stmtFarmacia.executeQuery(
                         "SELECT NIT, RAZON_SOCIAL, REPRESENTANTE_LEGAL, DIRECCION, ESTADO FROM FARMACIA")) {

                // PreparedStatement reutilizable para buscar ventas por farmacia
                String sqlVentas = "SELECT ID, FECHA_VENTA, CANTIDAD, TOTAL FROM VENTA WHERE NITFARMACIA = ?";
                try (PreparedStatement stmtVenta = conn.prepareStatement(sqlVentas)) {

                    while (rsFarmacia.next()) {
                        int nit = rsFarmacia.getInt("NIT");

                        // -- Construir la lista de ventas de esta farmacia --
                        List<Document> ventas = new ArrayList<>();
                        stmtVenta.setInt(1, nit);

                        try (ResultSet rsVenta = stmtVenta.executeQuery()) {
                            while (rsVenta.next()) {
                                Document venta = new Document("_id", new ObjectId())
                                        .append("id", rsVenta.getInt("ID"))
                                        .append("fechaVenta", rsVenta.getTimestamp("FECHA_VENTA").toLocalDateTime())
                                        .append("cantidad",   rsVenta.getInt("CANTIDAD"))
                                        .append("total",      rsVenta.getDouble("TOTAL"));
                                ventas.add(venta);
                                totalProcesado++;
                            }
                        }

                        // -- Construir el documento de farmacia con ventas embebidas --
                        Document docFarmacia = new Document("_id", new ObjectId())
                                .append("nit", nit)
                                .append("razonSocial",        rsFarmacia.getString("RAZON_SOCIAL"))
                                .append("representanteLegal", rsFarmacia.getString("REPRESENTANTE_LEGAL"))
                                .append("direccion",          rsFarmacia.getString("DIRECCION"))
                                .append("estado",             rsFarmacia.getString("ESTADO"))
                                .append("ventas",             ventas); // <-- array embebido

                        coleccionFarmacias.insertOne(docFarmacia);
                        totalProcesado++;
                    }
                }
            }
            System.out.println("Farmacias con ventas embebidas migradas correctamente.");

        } catch (Exception ex) {
            System.out.println("Error durante la migración: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        }

        long finGlobal = System.currentTimeMillis();

        String horaFin = LocalTime.now().format(fmt);
        System.out.println("==========================================");
        System.out.println("MIGRACIÓN FINALIZADA");
        System.out.println("Hora de inicio : " + horaInicio);
        System.out.println("Hora de fin    : " + horaFin);
        System.out.println("Total registros procesados: " + totalProcesado);
        System.out.println("Tiempo total: " + (finGlobal - inicioGlobal) / 1000.0 + " segundos");
        System.out.println("==========================================");

        return true;
    }
}