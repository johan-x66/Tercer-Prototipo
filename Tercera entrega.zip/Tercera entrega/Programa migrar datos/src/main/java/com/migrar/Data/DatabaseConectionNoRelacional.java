package com.migrar.Data;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import com.mongodb.MongoException;
public class DatabaseConectionNoRelacional {
    // The connection string (URI) for MongoDB.
    // Replace with your actual URI. For a local instance running on default port:
    private static final String CONNECTION_STRING = "mongodb://localhost:27017";
    private static final String DATABASE_NAME = "PER2026";

    private static MongoClient mongoClient = null;
    private static MongoDatabase database = null;

    public static MongoDatabase getDatabase(){
        if (database == null) {
            try {
                // 1. Crear el cliente de MongoDB
                mongoClient = MongoClients.create(CONNECTION_STRING);
                
                // 2. Acceder a la base de datos específica
                database = mongoClient.getDatabase(DATABASE_NAME);
                
                System.out.println("Conexión exitosa a MongoDB: " + DATABASE_NAME);
            } catch (MongoException e) {
                System.err.println("Error al conectar a MongoDB: " + e.getMessage());
            }
        }
        return database;
    }

    public static void closeConnection() {
        if (mongoClient != null) {
            mongoClient.close();
            System.out.println("Conexión a MongoDB cerrada.");
        }
    }
}
