package com.migrar.Data;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConectionRelacional {
    private static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:XE";
    private static final String USER = "JOHAN";
    private static final String PASS = "1966";

    public static Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");

            connection = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("[+] Conexion establecida");
        } catch (ClassNotFoundException e) {
            System.err.println("[+] Oracle JDBC no encontrado!");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("[+] Conexion fallida!");
            e.printStackTrace();
        }
        return connection;
    }
}
