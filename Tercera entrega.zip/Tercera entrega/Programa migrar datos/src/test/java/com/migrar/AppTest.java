package com.migrar;
import java.util.Scanner;

public class AppTest 
{
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        int opcion = -1;

        do {
            System.out.println("==========================================");
            System.out.println("   SISTEMA DE MIGRACIÓN DE DATOS         ");
            System.out.println("==========================================");
            System.out.println("  1. Migrar datos");
            System.out.println("  2. Salir");
            System.out.println("==========================================");
            System.out.print("Seleccione una opción: ");

            if (scanner.hasNextInt()) {
                opcion = scanner.nextInt();
            } else {
                scanner.next(); // limpiar entrada inválida
            }

            switch (opcion) {
                case 1:
                    System.out.println("\nIniciando migración...\n");
                    Migrar.migrarTodo();
                    break;
                case 2:
                    System.out.println("\nSaliendo del programa. ¡Hasta luego!");
                    break;
                default:
                    System.out.println("\nOpción no válida. Intente de nuevo.\n");
            }

        } while (opcion != 2);

        scanner.close();
    }
}
