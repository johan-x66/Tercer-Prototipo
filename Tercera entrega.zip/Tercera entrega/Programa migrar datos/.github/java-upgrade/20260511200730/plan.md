# Upgrade Plan: migrar (20260511200730)

- **Generated**: 2026-05-11 20:07:30
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- Java 25.0.1: C:\Program Files\Java\jdk-25\bin (available for build environment)
- Java 21: **<TO_BE_INSTALLED>** (required by step 1 for target runtime compatibility)
- Java 1.8: not available (baseline will be skipped)

**Build Tools**
- Maven: **<TO_BE_INSTALLED>** (required by step 1, no Maven installation detected)
- Maven Wrapper: not present in repository

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260511200730
- Run tests before and after the upgrade: true

## Upgrade Goals

- Upgrade Java runtime target to Java 21 (latest LTS)

## Technology Stack

| Technology/Dependency       | Current | Min Compatible | Why Incompatible |
| -------------------------- | ------- | -------------- | ---------------------------------------------- |
| Java                       | 1.8     | 21             | User requested latest LTS runtime              |
| Maven                      | none installed | 3.9.0+   | Java 21 requires Maven 3.9+                    |
| maven-compiler-plugin      | 3.8.0   | 3.11.0         | Older plugin versions cannot compile Java 21 bytecode |
| maven-surefire-plugin      | 2.22.1  | 3.1.0          | Older surefire has compatibility issues with newer JVMs |
| junit                      | 4.13.2  | 4.13.2         | Compatible, but build plugins must be updated  |
| mongodb-driver-sync        | 5.0.1   | 5.0.1          | Compatible with Java 21 at source level        |
| ojdbc8                     | 19.3.0.0| 19.3.0.0       | Likely compatible, but older Oracle driver certification with Java 21 needs verification |

## Derived Upgrades

- Install Java 21 for final compilation and target runtime verification.
- Install Maven 3.9+ because the local environment currently has no Maven installation and Java 21 requires Maven 3.9+.
- Update `maven-compiler-plugin` to `3.11.0` to support Java 21 compilation.
- Update `maven-surefire-plugin` to `3.1.0` to support tests on Java 21.
- Update project `maven.compiler.source` and `maven.compiler.target` to `21` to align code with the requested runtime.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Maven and JDK 21 are required before any source-level upgrade can be validated.
  - **Changes to Make**:
    - Install Maven 3.9+ into the local environment.
    - Install JDK 21 if not already present.
    - Confirm `mvn -v` and `java -version` against the new tools.
  - **Verification**: `mvn -v && java -version` using JDK 21 and Maven 3.9+; expected: versions reported correctly.

- Step 2: Setup Baseline
  - **Rationale**: Establish a baseline build state with the current project configuration if the current Java runtime is available.
  - **Changes to Make**:
    - Attempt baseline compilation with current project Java settings.
    - Document that Java 1.8 is not installed and baseline will be skipped.
  - **Verification**: baseline skipped because base JDK 1.8 is unavailable.

- Step 3: Update build configuration for Java 21
  - **Rationale**: The project is configured for Java 8 and requires build plugin upgrades and compiler settings to target Java 21.
  - **Changes to Make**:
    - Update `<maven.compiler.source>` and `<maven.compiler.target>` from `1.8` to `21`.
    - Upgrade `maven-compiler-plugin` to `3.11.0`.
    - Upgrade `maven-surefire-plugin` to `3.1.0`.
    - Keep other plugin versions unless proven incompatible during verification.
  - **Verification**: `mvn clean test-compile -q` using JDK 21; expected: build compiles successfully.

- Step 4: Final Validation
  - **Rationale**: Confirm the Java 21 upgrade is complete and all tests pass on the target runtime.
  - **Changes to Make**:
    - Run the full test suite on JDK 21.
    - Fix any compilation or test failures introduced by the upgrade.
  - **Verification**: `mvn clean test -q` using JDK 21; expected: all tests pass.

## Key Challenges

- **JDK version jump from 8 to 21**
  - **Challenge**: The project is currently configured for Java 8, while Java 21 requires newer compilation support and may expose compatibility issues at the build level.
  - **Strategy**: Update compiler and Surefire plugin versions before changing source/target to 21.

- **No local Maven installation detected**
  - **Challenge**: The environment has no Maven available, so the upgrade must install Maven before build verification can begin.
  - **Strategy**: Install Maven 3.9+ and use it to validate the build on JDK 21.

- **Baseline Java 1.8 not available**
  - **Challenge**: The repository is configured for Java 8, but JDK 8 is not installed, so a true pre-upgrade baseline cannot be created.
  - **Strategy**: Document the skipped baseline and proceed with the upgrade using the available newer JDK.

- **Oracle JDBC driver compatibility risk**
  - **Challenge**: `ojdbc8` 19.3.0.0 is older and may not be certified on Java 21.
  - **Strategy**: Verify compilation and runtime behavior; if necessary, upgrade to a newer Oracle JDBC driver after functional validation.
